import React from 'react'
export default class NoMatch extends React.Component {

    render() {
        return (
            <div style={{textAlign:'center',fontSize:'24'}}>
                404 No Found!!!
            </div>
        );
    }
}